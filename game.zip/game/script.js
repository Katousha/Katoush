var score = 0;
var scorevakje = document.querySelector("#scorevakje");

var cow = document.querySelector("#cow");
var pig = document.querySelector("#pig");
var chicken = document.querySelector("#chicken");

function goed () {
    score = score + 1;
    scorevakje.innerHTML = score;
    if (score == 4) {
        scorevakje.innerHTML = "Je bent koe-goed!";
    }
}
function fout (){
    score = score - 1;
    scorevakje.innerHTML = score;
}

cow.onclick = goed;
pig.onclick = fout;
chicken.onclick = fout;


